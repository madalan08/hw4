from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField
from wtforms import validators, StringField, SubmitField
class Add_form(FlaskForm):
    name = StringField("NAME")
    email = StringField("EMail:")
    phonenumber  = StringField("PHONE NUMBER:")
    address  = StringField("ADDRESS:")
    submit = SubmitField("ADD")
class DelForm(FlaskForm):
     phonenumber = IntegerField("PHONE NUMBER:")
     submit = SubmitField("DELETE")
class update_form(FlaskForm):
    name = StringField("NAME")
    email = StringField("EMail:")
    phonenumber  = StringField("PHONE NUMBER:")
    address  = StringField("ADDRESS:")
    submit = SubmitField("UPDATE")

