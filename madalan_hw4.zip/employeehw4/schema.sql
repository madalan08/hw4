drop table if exists company;
create table company(
  id integer primary key autoincrement,
  name text not null,
  email text not null,
  phonenumber text not null,
  address text not null
);
